import SwiftUI
import SceneKit

struct ContentView: View {
    @State private var scene: SCNScene?
    @State var shapeColor: CGColor = UIColor.blue.cgColor
    
    var body: some View {
        SceneKitView(scene: $scene)
            .onAppear {
                generate()
            }
    }
    func generate() {
        let scene = SCNScene()
        
        let material = SCNMaterial()
        material.diffuse.contents = shapeColor
        
        let Geometry = Geometry.Octahedron()
        Geometry.materials = [material]
        
        let Node = SCNNode()
        Node.geometry = Geometry
        
        scene.rootNode.addChildNode(Node)
        self.scene = scene
    }
}
