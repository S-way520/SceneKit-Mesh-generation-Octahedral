import SwiftUI
import SceneKit

struct SceneKitView: UIViewRepresentable {
    @Binding var scene: SCNScene?
    
    func makeUIView(context: Context) -> SCNView {
        let sceneView = SCNView()
        sceneView.backgroundColor = UIColor.systemBackground
        sceneView.autoenablesDefaultLighting = true
        sceneView.allowsCameraControl = true
        sceneView.scene = SCNScene()
        
        let camera = SCNCamera()
        camera.zFar = 100
        camera.zNear = 0.01
        
        let cameraNode = SCNNode()
        cameraNode.camera = camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 0.5) 
        cameraNode.eulerAngles = SCNVector3(x: 0, y: 0, z: 0)
        
        sceneView.pointOfView = cameraNode
        
        return sceneView
    }
    func updateUIView(_ uiView: SCNView, context: Context) {
        if let scene = scene {
            uiView.scene?.rootNode.childNodes.forEach { $0.removeFromParentNode() }
            uiView.scene?.rootNode.addChildNode(scene.rootNode)
        }
    }
}
