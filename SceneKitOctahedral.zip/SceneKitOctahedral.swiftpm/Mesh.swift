import SwiftUI
import SceneKit

struct Geometry {
    static func Octahedron() -> SCNGeometry {
        //Vertice
        let vertice: [SCNVector3] = [
            SCNVector3(0, 0.1, 0),
            SCNVector3(-0.05, 0, 0.05),
            SCNVector3(0.05, 0, 0.05),
            SCNVector3(0.05, 0, -0.05),
            SCNVector3(-0.05, 0, -0.05),
            SCNVector3(0, -0.1, 0),
        ]
        //Texture
        let textureCoordinate: [CGPoint] = [
            CGPoint(x: 0.5, y: 1.0), 
            CGPoint(x: 0.0, y: 0.5), 
            CGPoint(x: 0.5, y: 0.0), 
            CGPoint(x: 1.0, y: 0.5), 
            CGPoint(x: 0.5, y: 0.5),
            CGPoint(x: 0.5, y: 1.0),
            CGPoint(x: 0.0, y: 0.5),
            CGPoint(x: 0.5, y: 0.0)
        ]
        //Draw
        let indice: [UInt16] = [
            0, 1, 2,
            2, 3, 0,
            3, 4, 0,
            4, 1, 0,
            1, 5, 2,
            2, 5, 3,
            3, 5, 4,
            4, 5, 1
        ]
        
        let source = [
            SCNGeometrySource(vertices: vertice),
            SCNGeometrySource(textureCoordinates: textureCoordinate)
        ]
        let element = SCNGeometryElement(indices: indice, primitiveType: .triangles)
        
        return SCNGeometry(sources: source, elements: [element])
    }
}
